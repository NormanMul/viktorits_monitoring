
Getting Started
----------------

Bfree is built on top of [Next.js](https://nextjs.org/) and mostly what
applies to Next.js projects, should work here too.

### Prerequisites

At bare minimum you'll need a web browser that supports Web Bluetooth,
see [here](https://developer.mozilla.org/en-US/docs/Web/API/Web_Bluetooth_API#Browser_compatibility).

Only a few browsers support inhibiting screen locking from JS,
see [here](https://developer.mozilla.org/en-US/docs/Web/API/WakeLock).

The app is tested on Microsoft Edge and it should also work on Google Chrome and
its Android derivatives.

To build Bfree locally you'll need Node.js and `npm`.
The [official website](https://nodejs.org/en/) of the Node.js project
helps with that.

As normally with [Next.js](https://nextjs.org/) projects, the following
commands apply.

**Start in dev mode:**

```sh
npm run dev
```

**Run full build:**

```sh
npm run build
```

**Start in production mode:**

```sh
npm start
```

Running the build step is required before this.

### Next.js telemetry

The Next.js telemetry is disabled by default. You can opt-in for the telemetry
by setting the `NEXT_TELEMETRY_DISABLED` environment variable to `0`.



- [TCX Schema](https://www8.garmin.com/xmlschemas/TrainingCenterDatabasev2.xsd)
- [ThisIsAnt](https://www.thisisant.com/)
- [Bluetooth SIG - GATT specifications](https://www.bluetooth.com/specifications/gatt/)
