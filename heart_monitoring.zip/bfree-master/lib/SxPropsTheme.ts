import { SxProps } from '@mui/system';
import { Theme } from '@mui/material';

type SxPropsTheme = SxProps<Theme>;
export default SxPropsTheme;
